# README #
This is a serial of libraries that calculate image of textures from a remote sensing image, using fractal methods and GLCM method.


### What is this repository for? ###

* This repository is for users and professionals of remote sensing data.
* Version 0.1

### Who do I talk to? ###

* David Suárez dasuareza@correo.udistrital.edu.co, dasuarez85@gmail.com