#include "stdafx.h"
#include "DBC.h"


DBC::DBC(int **imagen, int M,int G)
{
	
	matriz=imagen;
	anchoMatriz=M;
	int s=anchoMatriz/2;
	float SD=0;
	int rangoColor;
	
	int suma=0;

	//guardar los resultado para todos los tama�os de s
	grafica=(interpretacion*) calloc(anchoMatriz/2-1,sizeof(interpretacion));
	int *v=(int*)calloc(anchoMatriz/2,sizeof(int));

	for (int i = 0; i < anchoMatriz/2-1; i++)
	{
		grafica[i].lN=0;
		grafica[i].lr=0;
	}

	//haya N para tama�os M>=s>1
	for (int s = 2; s <= anchoMatriz/2; s++)
	{
		suma++;
		rangoColor=G*s/anchoMatriz;
		//se calcula el tama�o de los grid y se calcula su N
		int N=DBC::calcularN(s,rangoColor);
		float r=(float)s/(float)anchoMatriz;
		float lN=log((float)N);
		float lr=log(1/r);
		float D=lN/lr;
		grafica[s-2].lN=lN;
		grafica[s-2].lr=lr;

		
		D=(float)((int)(D*1000000))/1000000;
		SD+=D;

	}
	printf("\n");
	
	SD=SD/(float)(anchoMatriz/2-1);
	DF=SD;
}


DBC::~DBC(void)
{
	for (int i = 0; i < anchoMatriz; i++)
	{
		free(matriz[i]);
	}

	free(matriz);
	free(grafica);
}

//devuelve el valor n de un grid sxs
int DBC::calculars(int s, int I, int J, int rangoColor){
	int k=257;
	int l=0;
	int n=0;
	for (int i = I; i < I+s; i++)
	{
		for (int j = J; j  < J+s; j++)
		{
			if(matriz[i][j]<k){
				k=matriz[i][j];
			}
			if(matriz[i][j]>l){
				l=matriz[i][j];
			}
		}
	}

	n=(l/rangoColor)-(k/rangoColor)+1;
	return n;
}

//Calcula N para un tama�o s dado
int DBC::calcularN(int s,int rangoColor){
	int N=0;

	for (int i = 0; i <= anchoMatriz-s; i+=s)
	{
		for (int j = 0; j  <= anchoMatriz-s; j+=s)
		{
			N+=DBC::calculars(s, i, j,rangoColor);
		}
	}
	return N;
}
void DBC::mostrarGrafica(){
	for (int i = 0; i < anchoMatriz/2-1; i++)
	{
		printf("%f;%f\n", grafica[i].lN, grafica[i].lr);
	}

}


