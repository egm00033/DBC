// box rgb.cpp: define el punto de entrada de la aplicaci�n de consola.
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include "LeerImagen.h"
#include "DimensioFractal.h"




int _tmain(int argc, _TCHAR* argv[])
{

	char *path=".\\images\\lena.bmp";
	long int  ancho, alto;
	int niveldeGris=256;

	int **imagen=LeerImagen::leerImagen(path, ancho, alto);



	//calcular N
	DimensioFractal c=DimensioFractal(imagen, ancho, niveldeGris);



	system ("pause");
	//liberar memoria
	for (int i = 0; i < alto; i++)
	{
		free(imagen[i]);
	}

	free(imagen);

	return EXIT_SUCCESS;
}

