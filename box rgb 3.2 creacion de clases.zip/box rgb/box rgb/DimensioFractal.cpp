#include "stdafx.h"
#include "DimensioFractal.h"


DimensioFractal::DimensioFractal(int **imagen, int M,int G)
{
	//haya N para tama�os M>=s>1
	matriz=imagen;
	anchoMatriz=M;
	int s=anchoMatriz/2;
	float SD=0;
	//se calcula el tama�o de los grid y se calcula su N
	int suma=0;
	for (int s = 2; s <= anchoMatriz/2; s++)
	{
		suma++;
		rangoColor=G*s/anchoMatriz;
		int N=DimensioFractal::calcularN(s);
		float r=(float)s/(float)anchoMatriz;
		float lN=log((float)N);
		float lr=log(1/r);
		float D=lN/lr;
		D=(float)((int)(D*1000000))/1000000;
		printf("%f;%f\n", float((int)(lN*100))/100, float((int)(lr*100))/100);

		SD+=D;

	}
	SD=SD/(float)(anchoMatriz/2-1);
	printf("D medio =%f",SD);
}


DimensioFractal::~DimensioFractal(void)
{
}

//devuelve el valor n de un grid sxs
int DimensioFractal::calculars(int s, int I, int J){
	int k=257;
	int l=0;
	int n=0;
	for (int i = I; i < I+s; i++)
	{
		for (int j = J; j  < J+s; j++)
		{
			if(matriz[i][j]<k){
				k=matriz[i][j];
			}
			if(matriz[i][j]>l){
				l=matriz[i][j];
			}
		}
	}

	n=(l/rangoColor)-(k/rangoColor)+1;
	return n;
}

//Calcula N para un tama�o s dado
int DimensioFractal::calcularN(int s){
	int N=0;

	for (int i = 0; i <= anchoMatriz-s; i+=s)
	{
		for (int j = 0; j  <= anchoMatriz-s; j+=s)
		{
			N+=DimensioFractal::calculars(s, i, j);
		}
	}
	return N;
}



