#pragma once
#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#define MAX_NOMARCH 256

namespace LeerImagen
{
int **leerImagen(char *nome,long &ancho,long &alto);
};

