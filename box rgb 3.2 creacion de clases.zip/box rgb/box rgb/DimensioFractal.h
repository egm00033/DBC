#pragma once
#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>

//G=nivel de gris(8bpp)
//M=tama�o de la imagen
//s=tama�o del grid M>=s>1
//s'=tamrangoColor=tama�o de cada particion del nivel de gris 
//k= minimo valor en sxs
//l= maximo valor en sxs
//n=l-k+1 en sxs
//N=Sumatoria n


class DimensioFractal
{
private:
	int **matriz;
	int anchoMatriz;
	int rangoColor;
	int calcularN( int s);
	int calculars(int s, int I, int J);
public:
	DimensioFractal(int **matriz, int M,int G);
	~DimensioFractal(void);

};

