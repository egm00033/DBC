// box rgb.cpp: define el punto de entrada de la aplicaci�n de consola.
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NOMARCH 256
#include <stdint.h>




int _tmain(int argc, _TCHAR* argv[])
{
	FILE *fpin;
	char *nome, str[MAX_NOMARCH + 1], id[] = "  ";
	long int despl, ancho, alto, bxp;

	if (argc > 1){
		nome ="";
		//nome = argv[1];
	}else {
		printf ("Archivo BMP que se va a transformar: ");
		//fgets (str, MAX_NOMARCH, stdin);
		//nome = str;
		nome=".\\images\\imagen2mini.bmp";
	}

	if ((fpin = fopen (nome,"rb")) == NULL) {
		fprintf (stderr, "Error al abrir el archivo %s\n", nome);
		exit (EXIT_FAILURE);
	}

	printf ("Datos de la imagen:\n");
	fread (id, 2, 1, fpin);
	printf ("\tIdentificador de bitmap: %s\n", id);
	fseek (fpin, 10L, SEEK_SET);
	fread (&despl, sizeof (long), 1, fpin);
	printf ("\tDesplazamiento a los datos: %ld\n", despl);
	fseek (fpin, 18L, SEEK_SET);
	fread (&ancho, sizeof (long), 1, fpin);
	fread (&alto, sizeof (long), 1, fpin);
	printf ("\tDimensiones de la imagen, ancho: %ld, alto: %ld\n", ancho, alto);
	fseek (fpin, 28L, SEEK_SET);
	fread (&bxp, sizeof (long), 1, fpin);
	printf ("\tBits por pixel: %ld\n", bxp);

	if (strcmp (id, "BM")){
		fprintf (stderr, "La imagen debe ser un bitmap.\n");
		// else if (bxp != 24)
		//fprintf (stderr, "La imagen debe ser de 24 bits.\n");
	}else {
		int i;
		FILE *fpout;
		fseek (fpin, 0L, SEEK_SET);
		fpout = fopen (".\\images\\saida.bmp", "wb");
		for (i = 0; i < despl; i++)
			fputc (fgetc (fpin), fpout);

		//pasar a 8bxp
		char bpp=8;
		//fwrite (&bpp, sizeof (char), 1, fpout);
		int recorte=4-(ancho)%4;
		if(recorte==4)recorte=0;
		ancho+=recorte;
		alto;
		char *matriz=new char [ancho*alto];
		printf("tama�o %d\n",ancho*alto);
		for (i = 0; i < (ancho) * (alto); i++) {
			char red;
			fread (&red, sizeof (char), 1, fpin);
			matriz[i]=red;
			//uint8_t i=red;
			fwrite (&red, sizeof (char), 1, fpout);

		}
		printf(" \n");
		
		//mostrar imagen
		for (i = 0; i < (ancho) * (alto); i++) {
			if(ancho-(i)%(ancho)<=recorte){
				//printf(" %i\t",matriz[i] & 0xff);
					printf("\n p%i m%i v%i \n",i,(i)%(ancho),matriz[i] & 0xff);
				printf("\n"); 
				
			}else{
				//printf(" %i\t",matriz[i] & 0xff);
				printf(" p%i m%i v%i \t",i,(i)%(ancho),matriz[i] & 0xff);
			}
			
		}
		printf("\n"); 
		printf("\n"); 


		//mostrar


		printf ("tam char : %i byte\n", sizeof (char));

		fclose (fpout);

		printf ("\n\tArchivo en escala de grises ----> saida.bmp\n");
	}
	fclose (fpin);

	system ("pause");
	return EXIT_SUCCESS;
}

