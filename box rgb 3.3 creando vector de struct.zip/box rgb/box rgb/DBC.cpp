#include "stdafx.h"
#include "DBC.h"


DBC::DBC(int **imagen, int M,int G)
{
	//haya N para tama�os M>=s>1
	matriz=imagen;
	anchoMatriz=M;
	int s=anchoMatriz/2;
	float SD=0;
	int rangoColor;
	//se calcula el tama�o de los grid y se calcula su N
	int suma=0;

	//guardar los resultado para todos los tama�os de s
	grafica=(interpretacion *) calloc(anchoMatriz/2,sizeof(interpretacion));
	for (int i = 0; i < anchoMatriz/2; i++)
	{
		grafica[i].lN=0;
		grafica[i].lr=0;
	}

	for (int s = 2; s <= anchoMatriz/2; s++)
	{
		suma++;
		rangoColor=G*s/anchoMatriz;
		int N=DBC::calcularN(s,rangoColor);
		float r=(float)s/(float)anchoMatriz;
		float lN=log((float)N);
		float lr=log(1/r);
		float D=lN/lr;
		/*grafica[0].lN=lN;
		grafica[0].lr=lr;*/
		grafica[0].lN=1;
		grafica[0].lr=1;

		D=(float)((int)(D*1000000))/1000000;
		printf("%f;%f\n", lN, lr);

		SD+=D;

	}
	printf("\n");
	for (int i = 0; i < anchoMatriz/2; i++)
	{
		printf("%f;%f\n", grafica[s-2].lN, grafica[s-2].lr);
	}
	SD=SD/(float)(anchoMatriz/2-1);
	printf("D medio =%f\n",SD);
}


DBC::~DBC(void)
{
	for (int i = 0; i < anchoMatriz; i++)
	{
		free(matriz[i]);
	}

	free(matriz);
}

//devuelve el valor n de un grid sxs
int DBC::calculars(int s, int I, int J, int rangoColor){
	int k=257;
	int l=0;
	int n=0;
	for (int i = I; i < I+s; i++)
	{
		for (int j = J; j  < J+s; j++)
		{
			if(matriz[i][j]<k){
				k=matriz[i][j];
			}
			if(matriz[i][j]>l){
				l=matriz[i][j];
			}
		}
	}

	n=(l/rangoColor)-(k/rangoColor)+1;
	return n;
}

//Calcula N para un tama�o s dado
int DBC::calcularN(int s,int rangoColor){
	int N=0;

	for (int i = 0; i <= anchoMatriz-s; i+=s)
	{
		for (int j = 0; j  <= anchoMatriz-s; j+=s)
		{
			N+=DBC::calculars(s, i, j,rangoColor);
		}
	}
	return N;
}



