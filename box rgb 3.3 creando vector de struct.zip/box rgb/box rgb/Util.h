#pragma once
#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#define MAX_NOMARCH 256

typedef struct {
	float lN; 
	float lr;
}interpretacion;



int **leerImagen(char *nome,long &ancho,long &alto);


