// box rgb.cpp: define el punto de entrada de la aplicaci�n de consola.
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include "Util.h"
#include "DBC.h"




int _tmain(int argc, _TCHAR* argv[])
{

	char *path=".\\images\\lena.bmp";
	long int  ancho, alto;
	int niveldeGris=256;

	int **imagen=leerImagen(path, ancho, alto);



	//calcular N
	DBC c=DBC(imagen, ancho, niveldeGris);



	system ("pause");
	//liberar memoria

	return EXIT_SUCCESS;
}

