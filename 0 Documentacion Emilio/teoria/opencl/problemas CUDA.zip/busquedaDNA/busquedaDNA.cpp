/*
 * Curso UNIA Gráficos: algo más que videojuegos
 * Autor: Antonio Rueda
 */

#include <cstdlib>
#include <fstream>
#include <iostream>

#include "busquedaCPU.h"
#include "busquedaGPU.h"

using namespace std;

#define TAM_DNA 250000
#define NUM_SEC 8000
#define TAM_SEC 12

/** Codificación de los 4 aminoacidos */
const char amin[] = "CTGA";

/** 
	Generar DNA aleatoriamente
	@param tam tamaño del DNA a generar
	@return un buffer con la secuencia generada
*/
char *generarDNA(int tam) {
	// Reservar memoria y generar el DNA
	char *dna = new char[tam];
	for (int c = 0; c < tam; ++c) dna[c] = amin[rand() % 4];

	return dna;
}

/** 
	Generar una lista de secuencias aleatorias con el tamaño indicado
	@param numSec número de secuencias
	@param tamSec tamaño de cada secuencia
	@return un buffer con la lista de secuencias generadas, separadas por '\0'
*/
char *generarSecuenciasBusqueda(int numSec, int tamSec) {
	char *listSec = new char[numSec * (tamSec + 1)];
	int pSec = 0;

	for (int cNumSec = 0; cNumSec < numSec; cNumSec++) {
		for (int cSec = 0; cSec < tamSec; cSec++) {
			listSec[pSec++] = amin[rand() % 4];
		}
		listSec[pSec++] = 0;
	}

	return listSec;
}

/** Programa principal */
int main( int argc, char** argv) 
{
	cout << "Generando DNA..." << endl;
	char *dna = generarDNA(TAM_DNA);

	cout << "Generando secuencias..." << endl;
	char *sec = generarSecuenciasBusqueda(NUM_SEC, TAM_SEC);

	cout << "Realizando búsquedas en CPU..." << endl;
	int *res = new int[NUM_SEC];
	busquedaCPU(dna, TAM_DNA, sec, NUM_SEC, TAM_SEC, res);

	int enc = 0;
	for (int c = 0; c < NUM_SEC; c++) {
		if (res[c] != -1) ++enc;
	}
	
	cout << "Secuencias encontradas: " << enc << endl;

	cout << "Realizando búsquedas en GPU..." << endl;
	int *resGPU = new int[NUM_SEC];
	busquedaGPU(dna, TAM_DNA, sec, NUM_SEC, TAM_SEC, resGPU);

	enc = 0;
	for (int c = 0; c < NUM_SEC; c++) {
		if (resGPU[c] != -1) ++enc;
	}

	cout << "Secuencias encontradas: " << enc << endl;

	delete[] dna;
	delete[] sec;
	delete[] res;
	delete[] resGPU;
}
