/*
 * Curso UNIA Gr�ficos: algo m�s que videojuegos
 * Autor: Antonio Rueda
 */

#ifndef _BUSQUEDACPU_H_
#define _BUSQUEDACPU_H_

/*
	Buscar una lista de subcadenas en una cadena principal
	@param cad la cadena principal
	@param lCad longitud de la cadena principal
	@param subCad lista de subcadenas, separados por '\0'
	@param lSubCad n�mero de subcadenas
	@param tSubCad tama�o de cada subcadena
	@param posSubCad resultados de la b�squeda. Posiciones de las subcadenas en la cadena principal
*/
void busquedaCPU(char *cad, int lCad, char *subCad, int lSubCad, int tSubCad, int *posSubCad); 

#endif