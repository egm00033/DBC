/*
 * Curso UNIA Gráficos: algo más que videojuegos
 * Autor: Antonio Rueda
 */

#include <cstdio>
#include <ctime>
#include "busquedaCPU.h"

void busquedaCPU(char *cad, int lCad, char *subCad, int lSubCad, int tSubCad, int *posSubCad) 
{
    unsigned int timer = 0;

    clock_t start = clock();
    int cCad2, cSubCad, maxCCad = lCad - tSubCad;

    // Iterar sobre todas las subcadenas a buscar
    for (int nSubCad = 0; nSubCad < lSubCad; ++nSubCad) {
        posSubCad[nSubCad] = -1;

	// Por cada una, recorrer toda la cadena principal
	for (int cCad = 0; cCad < maxCCad; cCad++) {
		cCad2 = cCad;
		cSubCad = nSubCad * (tSubCad + 1);
		// A partir de la posición en la cadena principal comprobar si coincide con la subcadena
		while (subCad[cSubCad] != 0 && subCad[cSubCad] == cad[cCad2]) {
			++cSubCad;
			++cCad2;
		}
		// Si se ha recorrido la subcadena completa, apuntar su posici�n y pasar a la siguiente
		if (subCad[cSubCad] == 0) {
			posSubCad[nSubCad] = cCad;
			break;
		}
	}
    }

    printf( "Tiempo procesamiento CPU: %f (ms)\n", (clock() - start) * 1000.0 / CLOCKS_PER_SEC);
}
