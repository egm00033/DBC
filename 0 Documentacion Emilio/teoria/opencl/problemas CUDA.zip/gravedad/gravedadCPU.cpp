/*
 * Curso UNIA Gr�ficos: algo m�s que videojuegos
 * Autor: Antonio Rueda
 */

#include <cmath>
#include <cstdio>
#include <ctime>
#include "gravedadCPU.h"

// Constante de gravitación
#define G 0.0001f

void gravedadCPU(float *m, float *p, float *v, int n, int nPasos) 
{
	float r[2], rn, r2, ac, ac2;

    	clock_t start = clock();

	for (int t = 0; t < nPasos; t++) {
		for (int c = 0; c < n; c++) {
			for (int c2 = c + 1; c2 < n; c2++) {
				// Calcular el vector r entre los cuerpos c2 y c
				r[0] = p[2 * c2] - p[2 * c];
				r[1] = p[2 * c2 + 1] - p[2 * c + 1];

				// Calcular distancia entre los dos cuerpos al cuadrado
				r2 = r[0] * r[0] + r[1] * r[1];

				// Aceleraciones de cada cuerpo por la fuerza gravitatoria
				ac = G * m[c2] / r2;
				ac2 = G * m[c] / r2;

				// Normalizar el vector r
				rn = sqrt(r2);
				r[0] /= rn;
				r[1] /= rn;

				// Actualizar la velocidad del cuerpo 1
				v[2 * c] += r[0] * ac;
				v[2 * c + 1] += r[1] * ac;

				// Actualizar la velocidad del cuerpo 2
				v[2 * c2] += -r[0] * ac2;
				v[2 * c2 + 1] += -r[1] * ac2;
			}

			// Actualizar la posición del cuerpo
			p[2 * c] += v[2 * c];
			p[2 * c + 1] += v[2 * c + 1];
		}
	}

    printf( "Tiempo procesamiento CPU: %f (ms)\n", (clock() - start) * 1000.0 / CLOCKS_PER_SEC);
}
