/*
 * Curso UNIA Gr�ficos: algo m�s que videojuegos
 * Autor: Antonio Rueda
 */

#include <cstdlib>
#include <iostream>
#include <ctime>
#include <algorithm>

#include "gravedadCPU.h"
#include "gravedadGPU.h"

#define NCUERPOS 2000
#define NITERACIONES 100

/** Generar aleatoriamente los parámetros (masa, posición, velocidad) 
de un conjunto de cuerpos 
	@param m array de masas
	@param p array de posiciones
	@param v array de velocidades
	@param n número de cuerpos
*/
void generarParametrosCuerpos(float *m, float *p, float *v, int n) {
	for (int c = 0; c < n; c++) {
		// Masa entre 0 y 1
		*(m++) = (float) rand()/RAND_MAX;

		// Posición en el cuadrado 0..1
		*(p++) = (float) rand()/RAND_MAX;
		*(p++) = (float) rand()/RAND_MAX;

		// Velocidades (parados inicialmente)
		*(v++) = 0;
		*(v++) = 0;
	}
}

int main( int argc, char** argv) 
{
	// Masas
	float *m = new float[NCUERPOS];
	// Posiciones (px, py)
	float *p = new float[2 * NCUERPOS];
	// Velocidades (vx, vy)
	float *v = new float[2 * NCUERPOS];

	generarParametrosCuerpos(m, p, v, NCUERPOS);

	// Bucle de simulación CPU
	std::cout << "Simulando en CPU..." << std::endl;
	gravedadCPU(m, p, v, NCUERPOS, NITERACIONES);

	// Bucle de simulación GPU
	std::cout << "Simulando en GPU..." << std::endl;
	gravedadGPU(m, p, v, NCUERPOS, NITERACIONES);

	delete[] m;
	delete[] p;
	delete[] v;
}
