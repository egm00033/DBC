/*
 * Curso UNIA Gr�ficos: algo m�s que videojuegos
 * Autor: Antonio Rueda
 */

#ifndef _GRAVEDADCPU_H_
#define _GRAVEDADCPU_H_

/** Simular el movimiento de los cuerpos durante el n�mero de pasos indicado. Versi�n CPU
	@param m array de masas
	@param p array de posiciones (2 componentes)
	@param v array de velocidads (2 componentes)
	@param n n�mero de cuerpos
	@param nPasos n�mero de pasos a simular
*/
void gravedadCPU(float *m, float *p, float *v, int n, int nPasos); 

#endif