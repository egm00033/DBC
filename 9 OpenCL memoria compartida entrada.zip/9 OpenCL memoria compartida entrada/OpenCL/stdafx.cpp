/**
@file stdafx.cpp
@brief archivo de c�digo fuente que contiene s�lo las inclusiones est�ndar
OpenCL.pch ser� el encabezado precompilado
stdafx.obj contiene la informaci�n de tipos precompilada

@author Emilio Gallardo Molina
@date 24/04/2017
*/
#include "stdafx.h"

// TODO: mencionar los encabezados adicionales que se necesitan en STDAFX.H
// pero no en este archivo
