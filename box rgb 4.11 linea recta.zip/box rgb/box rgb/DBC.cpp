#include "stdafx.h"
#include "DBC.h"


DBC::DBC(int **imagen, int M,int G)
{
	matriz=imagen;
	anchoMatriz=M;
	int s=anchoMatriz/2;
	float SD=0;
	float rangoColor;

	numElementos=0;

	//guardar los resultado para todos los tama�os de s
	grafica=(interpretacion*) calloc(anchoMatriz/2-1,sizeof(interpretacion));
	int *v=(int*)calloc(anchoMatriz/2,sizeof(int));

	for (int i = 0; i < anchoMatriz/2-1; i++)
	{
		grafica[i].lN=0;
		grafica[i].lr=0;
	}

	//haya N para tama�os M>=s>1
	for (int s = 2; s <= anchoMatriz/2; s++)
	{
		if(anchoMatriz%s==0){
			
			rangoColor=(float)G/(float)s;
			int N=DBC::calcularN(s,rangoColor);

			float r=(float)s/(float)anchoMatriz;
			float lN=log10((float)N);
			float lr=log10(1/r);
			float D=lN/lr;
			grafica[numElementos].lN=log10((float)N);
			grafica[numElementos].lr=log10(1/r);


			D=(float)((int)(D*100))/100;//redondear
			SD+=D;
			printf("%i \t| s=%i \t|r=%f\t|N=%i \t| D=%f\t|\n",numElementos,s,r,N,D);
			printf("\t\t|lr=%f \t|lN=%f\n\n",lr,lN);
			numElementos+=1;
		}
	}
	printf("\n");

	SD=SD/(float)(numElementos);
	//df guarda el valor medio de D 
	DF=SD;
}


DBC::~DBC(void)
{
	for (int i = 0; i < anchoMatriz; i++)
	{
		free(matriz[i]);
	}

	free(matriz);
	free(grafica);
}

//devuelve el valor n de un grid sxs
int DBC::calculars(int s, int I, int J, float rangoColor){
	int k=257;
	int l=0;
	int n=0;
	for (int i = I; i < I+s; i++)
	{
		for (int j = J; j  < J+s; j++)
		{
			if(matriz[i][j]<k){
				k=matriz[i][j];
			}
			if(matriz[i][j]>l){
				l=matriz[i][j];
			}
		}
	}

	l=(int)(l/rangoColor);
	k=(int)(k/rangoColor);
	//if((int)(l/rangoColor)!=(l/(int)rangoColor))
	//printf("cambia el resultado %i!=%i\n",(int)(l/rangoColor),(l/(int)rangoColor));
	n=l-k+1;
	//printf("\n%i=%i-%i+1\n",n,l,k);



	return n;
}

//Calcula N para un tama�o s dado
int DBC::calcularN(int s,float rangoColor){
	int N=0;

	for (int i = 0; i <= anchoMatriz-s; i+=s)
	{
		for (int j = 0; j  <= anchoMatriz-s; j+=s)
		{
			N+=DBC::calculars(s, i, j,rangoColor);
		}
		//printf("-------\n");
	}

	//printf("s= %i, rango=%f, N= %i\t",s,rangoColor,N);

	return N;
}

void DBC::mostrarGrafica(){
	printf("1/r;N;log(1/r);log(N) \n\n");
	for (int i = numElementos-1; i >= 0; i--)
	{	
		printf("%f;%f;%f;%f;\n",  grafica[i].lr,grafica[i].lN,grafica[i].lr,grafica[i].lN);
	}

}

float DBC::calcularPendiente(){
	int i=0;

	float a=0.0;
	float b=0.0;
	float penxy=0.0;
	float sumax=0.0;
	float sumay=0.0;
	float sumx2=0.0;
	float sumy2=0.0;
	//int tam=5;
	int tam=numElementos+=1;;
	//float x[]={0.2,0.5,1,2,3}; // peso
	//float y[]={8,10,18,35,60}; // estatura
	//inicia la parte de regresion lineal
	for(i=0;i<tam;i++){
		sumax+=grafica[i].lN;
		sumay+=grafica[i].lr;
		sumx2+=grafica[i].lN*grafica[i].lN;
		sumy2+=grafica[i].lr*grafica[i].lr;
		penxy+=grafica[i].lN*grafica[i].lr;
	}
	/*printf("sumax %f\n",sumax);
	printf("sumay %f\n",sumay);
	printf("sumx2 %f\n",sumx2);
	printf("sumy2 %f\n",sumy2);
	printf("penxy %f\n",penxy);*/

	// inicia correlaci�n agregado

	float mediaX=sumax/(float)(tam);
	float mediaY=sumay/(float)(tam);
	//printf("mediaX %f\n",mediaX);
	//printf("mediaY %f\n",mediaY);

	float pxy=0.0;
	for(int i=0; i<tam; i++){
		pxy+=(grafica[i].lN-mediaX)*(grafica[i].lN-mediaY);
	}
	//printf("pxy %f\n",pxy);
	a=((float)(tam)*penxy-sumax*sumay)/((float)(tam)*sumx2-sumax*sumax);
	b=(sumay-a*sumax)/(float)(tam);
	printf("\n el valor de a es ;%f ;\n",a);
	printf("el valor de b es ;%f ;\n",b);
	printf("1/r=b+a*N ;\n");

	float S2x=sumx2/tam-(sumax/tam)*(sumax/tam);
	float S2y=sumy2/tam-(sumay/tam)*(sumay/tam);
	//el coeficiente de la correlaci�n
	//printf("S2x %f\n",S2x);
	//printf("S2y %f\n",S2y);

	float correlacion=pxy/tam/((sqrt(S2x)*sqrt(S2y)));
	//printf("correlacion %f\n",correlacion);
	//printf(" el indice de correlaci�n es: %f\n",correlacion);
	// fin correlaci�n
	return correlacion;
}


